package main

import (
    "encoding/json"
    "net/http"
    "database/sql"
    _ "github.com/lib/pq"
)

type Review struct {
    Text     string `json:"text"`
    Sentiment int   `json:"sentiment"`
}

func getReviews(w http.ResponseWriter, r *http.Request) {
    db, _ := sql.Open("postgres", "user=youruser dbname=yourdb sslmode=disable")
    rows, _ := db.Query("SELECT review_text, sentiment FROM reviews LIMIT 5")

    var reviews []Review
    for rows.Next() {
        var rev Review
        rows.Scan(&rev.Text, &rev.Sentiment)
        reviews = append(reviews, rev)
    }

    json.NewEncoder(w).Encode(reviews)
}

func main() {
    http.HandleFunc("/reviews", getReviews)
    http.ListenAndServe(":8080", nil)
}
