CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE reviews (
    id SERIAL PRIMARY KEY,
    review_text TEXT,
    sentiment INT,
    embedding VECTOR(300)
);
