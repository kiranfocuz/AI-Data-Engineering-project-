import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import psycopg2
from pgvector.psycopg2 import register_vector

# Load data
data = pd.read_csv('../data/product_reviews.csv')
X = data['review_text']
y = data['stars'].apply(lambda x: 1 if x >= 4 else 0)

# Vectorize
vec = TfidfVectorizer()
X_vec = vec.fit_transform(X)

# Train model
model = LogisticRegression()
model.fit(X_vec, y)

# Store embeddings and predictions
def store_vector_embeddings():
    conn = psycopg2.connect(dbname="yourdb", user="youruser", password="yourpass")
    register_vector(conn)
    cur = conn.cursor()

    for idx, text in enumerate(X):
        emb = vec.transform([text]).toarray()[0].tolist()
        cur.execute("INSERT INTO reviews (review_text, embedding, sentiment) VALUES (%s, %s, %s)", 
                    (text, emb, int(y[idx])))

    conn.commit()
    cur.close()
    conn.close()
